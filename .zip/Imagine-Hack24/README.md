# To start the project

npm install

npm run dev

test